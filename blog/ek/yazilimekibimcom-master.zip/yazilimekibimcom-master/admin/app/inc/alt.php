        <!-- jQuery -->
        <script src="<?php echo URL; ?>public/admin/js/jquery.min.js"></script>
        <script src="<?php echo URL; ?>public/admin/js/bootstrap.min.js"></script>
        <script src="<?php echo URL; ?>public/admin/js/metisMenu.min.js"></script>
        <script src="<?php echo URL; ?>public/admin/js/startmin.js"></script>
		<script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>
    </body>
</html>