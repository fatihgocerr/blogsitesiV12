	<footer> 
		<div class="container-fluid" style="background-color: #41A7EA;border-top:1px solid #000;">
			<div class="container" id="alt">
				<div class="col-md-12">
					<p class="text-right imza">
						<a href="http://www.mustafayilmaz.ist">Mustafa Yılmaz</a>
					</p>
				</div>
			</div>
		</div>
	</footer>