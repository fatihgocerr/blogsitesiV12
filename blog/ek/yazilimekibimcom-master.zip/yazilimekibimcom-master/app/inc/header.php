	<header>
		<div class="container-fluid" style="background-color: #41A7EA;">
			<div class="container" id="ust">
				<div class="col-md-2">
					<img src="public/img/logo.png" alt="" width="80">
				</div>
				<div class="col-md-10">
				<ul class="ust_menu text-right">
						<li><a href="index.php">ANA SAYFA</a></li>
						<li><a href="index.php?url=hakkimda">HAKKIMDA</a></li>
						<li><a href="index.php?url=iletisim">İLETİŞİM</a></li>
					</ul>
				</div>
			</div>
		</div>
	</header>