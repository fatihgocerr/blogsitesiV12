<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>yazilimekip::</title>
	<link rel="stylesheet" href="<?php echo URL; ?>public/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo URL; ?>/public/css/color.css">
	<link rel="stylesheet" href="<?php echo URL; ?>/public/css/style.css">
</head>
<body>