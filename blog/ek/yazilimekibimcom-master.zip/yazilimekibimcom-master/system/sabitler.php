<?php 


define("URL","http://www.yazilimekibim.com/");
$veritabani["host"]="mysql:host=localhost;dbname=database_adi;charset=utf8";
$veritabani["user"]="database_kullanıcı_adi";
$veritabani["password"]="database_şifresi";